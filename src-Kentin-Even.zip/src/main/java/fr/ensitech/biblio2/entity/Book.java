package fr.ensitech.biblio2.entity;


import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name="book", catalog = "biblio-database")
@Getter @Setter @ToString @NoArgsConstructor @AllArgsConstructor
public class Book {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "title", nullable = false, length = 48)
  private String title;

  @Column(name = "description", nullable = false)
  private String description;

  @Column(name = "published", nullable = false)
  private boolean published;

  @Column(name = "editor", nullable = false, length = 64)
  private String editor;

  @Column(name = "publicationDate", nullable = false)
  @Temporal(TemporalType.DATE)
  private Date publicationDate;

  @Column(name = "isbn", nullable = false, length = 13)
  private String isbn;

  @Column(name = "nbPage", nullable = false)
  private Integer nbPage;

  @Column(name = "category", nullable = false, length = 48)
  private String category;

  @Column(name = "language", nullable = false, length = 48)
  private String language;
}
