package fr.ensitech.biblio2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Biblio2Application {

	public static void main(String[] args) {
		SpringApplication.run(Biblio2Application.class, args);
	}

}
