package fr.ensitech.biblio2.service;

import fr.ensitech.biblio2.entity.Book;

import java.util.Date;
import java.util.List;

public interface IBookService {

  List<Book> getPublishedBooks() throws Exception;
  Book getBookByTitle(String title) throws Exception;
  List<Book> searchBooksByTitleContaining(String title) throws Exception;
  Book getBookByIsbn(String isbn) throws Exception;
  List<Book> searchBooksByTitleOrDescription(String text) throws Exception;
  List<Book> getBooksByPublicationDateBetween(Date startDate, Date endDate) throws Exception;
}