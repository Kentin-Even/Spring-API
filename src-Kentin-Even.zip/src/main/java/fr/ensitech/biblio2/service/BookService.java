package fr.ensitech.biblio2.service;

import fr.ensitech.biblio2.entity.Book;
import fr.ensitech.biblio2.repository.IBookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BookService implements IBookService {

  @Autowired
  private IBookRepository bookRepository;

  @Override
  public List<Book> getPublishedBooks() throws Exception {
    return bookRepository.findByPublished(true);
  }

  @Override
  public Book getBookByTitle(String title) throws Exception {
    Optional<Book> optional = bookRepository.findByTitle(title);
    return optional.orElse(null);
  }

  @Override
  public List<Book> searchBooksByTitleContaining(String title) throws Exception {
    return bookRepository.findByTitleContainingIgnoreCase(title);
  }

  @Override
  public Book getBookByIsbn(String isbn) throws Exception {
    Optional<Book> optional = bookRepository.findByIsbn(isbn);
    return optional.orElse(null);
  }

  @Override
  public List<Book> searchBooksByTitleOrDescription(String text) throws Exception {
    return bookRepository.findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(text, text);
  }

  @Override
  public List<Book> getBooksByPublicationDateBetween(Date startDate, Date endDate) throws Exception {
    return bookRepository.findByPublicationDateBetween(startDate, endDate);
  }
}