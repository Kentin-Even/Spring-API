package fr.ensitech.biblio2.repository;

import fr.ensitech.biblio2.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface IBookRepository extends JpaRepository<Book, String> {

  List<Book> findByPublished(boolean published);
  Optional<Book> findByTitle(String title);
  List<Book> findByTitleContainingIgnoreCase(String title);
  Optional<Book> findByIsbn(String isbn);
  List<Book> findByTitleContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String title, String description);
  List<Book> findByPublicationDateBetween(Date startDate, Date endDate);
}