package fr.ensitech.biblio2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Biblio2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
